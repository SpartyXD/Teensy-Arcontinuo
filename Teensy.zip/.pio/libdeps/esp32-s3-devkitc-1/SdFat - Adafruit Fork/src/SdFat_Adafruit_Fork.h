#ifndef SDFAT_ADAFRUIT_FORK_H
#define SDFAT_ADAFRUIT_FORK_H

#include "SdFat.h"

#endif // SDFAT_ADAFRUIT_FORK_H
